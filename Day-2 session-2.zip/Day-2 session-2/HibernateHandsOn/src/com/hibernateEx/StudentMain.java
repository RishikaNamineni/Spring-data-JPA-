package com.hibernateEx;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class StudentMain {

	private static SessionFactory factory;
	
	public static void main(String[] args) {
		
		try {
			
			factory = new Configuration()
					.configure("hibernate.cfg.xml")
					.addAnnotatedClass(Student.class)
					.buildSessionFactory();
		}
		catch(Throwable ex) {
			System.out.println("Failed to create an session factory object" +ex);
			 throw new ExceptionInInitializerError(ex); 
		}
		
		StudentMain sm = new StudentMain();
		
		Integer studId1 = sm.addStudent("Yashu", "Yashoda", "yash333@gmail.com");
		Integer studId2 = sm.addStudent("Teju", "Tejaswini", "tej123@gmail.com");
		Integer studId3 = sm.addStudent("Maggie", "Meghana", "maggie@gmail.com");
		
		sm.listStudents();
		
		sm.updateStudent(studId2, "tejaswi123@gmail.com");
		
		sm.deleteStudent(studId3);
		
		sm.listStudents();
								
	}
	
	public Integer addStudent(String firstName, String lastName, String email) {
		Session session = factory.openSession();
		Transaction tx =  null;
		Integer  studentId = null;
		
		try {
	         tx = session.beginTransaction();
	         Student student = new Student();
	         student.setFirstName(firstName);
	         student.setLastName(lastName);
	         student.setemail(email);
	         
	         studentId = (Integer)session.save(student);
	         tx.commit();
		}
		catch(HibernateException ex) {
			if(tx!=null) tx.rollback();
			ex.printStackTrace();
		}
		finally {
			session.close();
		}
		return studentId;
	}
	
	public void listStudents() {
		Session session = factory.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			List students = session.createQuery("From Student").list();
			for(@SuppressWarnings("rawtypes")
			Iterator iterator = students.iterator(); iterator.hasNext();) {
				Student student = (Student)iterator.next();
				
				System.out.println("FirstName : " + student.getFirstName());
				System.out.println("LastName :" + student.getLastName());
				System.out.println("Email : "+ student.getemail());
			}
			
		}
		catch(HibernateException ex) {
			if(tx!=null) tx.rollback();
			ex.printStackTrace();
		}
		finally {
			session.close();
		}
	} 
	
	public void updateStudent(Integer studentId,String email ) {
		
		Session session = factory.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
	         Student student = (Student)session.get(Student.class, studentId); 
	         student.setemail( email );
	         session.update(student); 
	         tx.commit();
		}
		catch(HibernateException ex) {
			if(tx!=null) tx.rollback();
			ex.printStackTrace();
	   }
		finally {
			session.close();
		}
	}
	
		 /* Method to DELETE an employee from the records */
		   public void deleteStudent(Integer studentId){
		      Session session = factory.openSession();
		      Transaction tx = null;
		      
		      try {
		         tx = session.beginTransaction();
		         Student student = (Student)session.get(Student.class, studentId); 
		         session.delete(student); 
		         tx.commit();
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
		   }
		   
	}
		 

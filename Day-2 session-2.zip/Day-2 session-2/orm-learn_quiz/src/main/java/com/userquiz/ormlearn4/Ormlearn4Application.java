package com.userquiz.ormlearn4;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.userquiz.ormlearn4.model.Attempt;
import com.userquiz.ormlearn4.model.User;
import com.userquiz.ormlearn4.service.AttemptService;

@SpringBootApplication
public class Ormlearn4Application {

	private static final Logger LOGGER = LoggerFactory.getLogger(Ormlearn4Application.class);
	private static AttemptService attemptService;
	
	public static void main(String[] args) {
		SpringApplication.run(Ormlearn4Application.class, args);
		ApplicationContext context = SpringApplication.run(Ormlearn4Application.class, args);
		attemptService = context.getBean(AttemptService.class);
		LOGGER.info("Inside main"); 
		testGetAttempt();
	}
	
	public static void testGetAttempt() {
		Attempt a=attemptService.getAttemptById();
		System.out.println(a);
		}

}

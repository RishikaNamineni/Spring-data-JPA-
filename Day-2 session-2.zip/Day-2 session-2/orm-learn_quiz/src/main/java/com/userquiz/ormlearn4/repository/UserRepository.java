package com.userquiz.ormlearn4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userquiz.ormlearn4.model.User;

public interface UserRepository extends JpaRepository<User, String>{

}

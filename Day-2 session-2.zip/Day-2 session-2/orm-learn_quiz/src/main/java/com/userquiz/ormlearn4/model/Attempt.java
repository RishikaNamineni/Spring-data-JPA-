package com.userquiz.ormlearn4.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "question")

public class Attempt {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "at_id")
	private int id;
	
	@Column(name = "at_date")
	private Date date;
	
	@Column(name = "at_score")
	private double score;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "at_us_id")
	private User user;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "aq_qt_id")
	private Set<Question> questions;
	
	@ManyToMany(fetch = FetchType.EAGER)
	private Set<Options> options;

	
	
	public Attempt(int id, Date date, double score, User user, Set<Question> questions, Set<Options> options) {
		super();
		this.id = id;
		this.date = date;
		this.score = score;
		this.user = user;
		this.questions = questions;
		this.options = options;
	}

	
	
	public Attempt() {
		super();
		// TODO Auto-generated constructor stub
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public Set<Options> getOptions() {
		return options;
	}

	public void setOptions(Set<Options> options) {
		this.options = options;
	}

}


package com.userquiz.ormlearn4.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userquiz.ormlearn4.model.Attempt;
import com.userquiz.ormlearn4.repository.AttemptRepository;


@Service
public class AttemptService {

	@Autowired
	private AttemptRepository attemptRepository;
	
	@Transactional
	public Attempt getAttemptById() {
		return attemptRepository.getAttempt(1,1);
	}
}

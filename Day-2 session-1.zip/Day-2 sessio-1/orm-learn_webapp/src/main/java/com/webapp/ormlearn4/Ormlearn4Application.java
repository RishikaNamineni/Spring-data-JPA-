package com.webapp.ormlearn4;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.webapp.ormlearn4.service.CountryService;

@SpringBootApplication
public class Ormlearn4Application {

	private static final Logger LOGGER = LoggerFactory.getLogger(Ormlearn4Application.class);
	@SuppressWarnings("unused")
	private static CountryService countryService;
	
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Ormlearn4Application.class, args);
		countryService = context.getBean(CountryService.class);
		
		LOGGER.info("Inside Main");
		
	}

}

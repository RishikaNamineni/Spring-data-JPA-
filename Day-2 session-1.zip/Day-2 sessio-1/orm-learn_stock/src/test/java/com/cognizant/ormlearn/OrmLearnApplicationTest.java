package com.cognizant.ormlearn;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrmLearnApplicationTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}

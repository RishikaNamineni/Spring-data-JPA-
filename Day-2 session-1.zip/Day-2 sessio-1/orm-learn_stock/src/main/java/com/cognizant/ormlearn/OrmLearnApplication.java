package com.cognizant.ormlearn;


import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.repository.StockRepository; 


@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	
	@Autowired
	public StockRepository stockRepository;
	
	@Transactional 
	public List<Stock> getAllFacebook() {
		Date date = null, date2 = null;
		
		date = Date.valueOf("2019-09-01");
		date2 = Date.valueOf("2019-09-30");
		
		return stockRepository.findByCodeAndDateBetween("FB",date,date2);
	}
	

	@Transactional
	public List<Stock> getAllGoogle() {
		return stockRepository.findByCloseGreaterThan(1250);
	}

	@Transactional
	public List<Stock> highest5Transactions() {
		return stockRepository.findFirst3ByOrderByVolumeDesc();
	}

	@Transactional
	public List<Stock> lowest3TransactionsNFLX() {
		return stockRepository.findFirst3ByCodeOrderByCloseAsc("NFLX");
	}
	
	
	
	public static void main(String[] args) {
		
		LOGGER.info("Start Stock");
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		OrmLearnApplication application = context.getBean(OrmLearnApplication.class);
		
		List<Stock> list = application.getAllFacebook();
		
		for(Stock stock : list) {
			System.out.println(stock.toString());
		}
		
		list = application.getAllGoogle();
		for(Stock stock : list) {
			System.out.println(stock.toString());
		}
		
		list = application.highest5Transactions();
		for (Stock stock : list) {
			System.out.println(stock.toString());
		}

		list = application.lowest3TransactionsNFLX();
		for (Stock stock : list) {
			System.out.println(stock.toString());
		}
		LOGGER.info("End Stock");
	}

}

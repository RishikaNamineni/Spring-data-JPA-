package com.cognizant.ormpayroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmPayrollApplicationTests {

	@Test
	void contextLoads() {
	}

}

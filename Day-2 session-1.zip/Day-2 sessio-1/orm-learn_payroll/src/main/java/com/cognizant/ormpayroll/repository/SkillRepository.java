package com.cognizant.ormpayroll.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.ormpayroll.model.Skill;

public interface SkillRepository extends JpaRepository<Skill, Integer>{

}

package com.cognizant.ormpayroll;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormpayroll.model.Department;
import com.cognizant.ormpayroll.model.Employee;
import com.cognizant.ormpayroll.model.Skill;
import com.cognizant.ormpayroll.service.DepartmentService;
import com.cognizant.ormpayroll.service.EmployeeService;
import com.cognizant.ormpayroll.service.SkillService;

@SpringBootApplication
public class OrmPayrollApplication {
	
	public static EmployeeService employeeService;
	public static DepartmentService departmentService;
	public static SkillService skillService;
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmPayrollApplication.class);
	
	private static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.info("End");
		LOGGER.debug("Skills:{}", employee.getSkillList());
		}

	public static void testAddEmployee() {
		LOGGER.info("Start");
		Employee employee = new Employee();
		employee.setName("Raka");
		employee.setSalary(50000.00);
		employee.setPermanent(true);
		employee.setDateOfBirth(Date.valueOf("1995-02-21"));
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}
	
	public static void testUpdateEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(2);
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}
	
	public static void testGetDepartment() {
		LOGGER.info("Start");
		Department department = departmentService.get(1);
		LOGGER.debug("Department:{}", department);
		Set<Employee> employees = department.getEmployeeList();
		LOGGER.debug("Employee List:{}", employees);
		LOGGER.info("End");
	}
	
	public static void testAddSkillToEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(3);
		Skill skill = skillService.get(2);
		employee.getSkillList().add(skill);
		employeeService.save(employee);
		LOGGER.info("End");
	}

	public static void testGetAllPermanentEmployees() {
		
		LOGGER.info("Start");
		List<Employee> employees = employeeService.getAllPermanentEmployees();
		LOGGER.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
		LOGGER.info("End");
		}
	public static void testGetAvgSalary()
	{
		employeeService.getAvgSalary(1);
	}
	public static void testGetAllEmployeesNative()
	{
		employeeService.getAllEmployeesNative();
	}
	
	
	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(OrmPayrollApplication.class, args);
		OrmPayrollApplication application = context.getBean(OrmPayrollApplication.class);
		
		employeeService = context.getBean(EmployeeService.class);
		departmentService = context.getBean(DepartmentService.class);
		skillService = context.getBean(SkillService.class);
		
		testGetEmployee();
		testAddEmployee();
		testUpdateEmployee();
		testGetDepartment();
		testAddSkillToEmployee();
	}

}

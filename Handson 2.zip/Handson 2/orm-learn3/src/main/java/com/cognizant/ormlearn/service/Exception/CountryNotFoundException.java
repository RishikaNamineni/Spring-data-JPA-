package com.cognizant.ormlearn.service.Exception;

public class CountryNotFoundException  extends Exception{

}
